## Auth Lib

React-компоненты и клиент, не зависящий от фреймворка, для серверного OAuth 2.0 Authorization Code flow с PKCE.

Браузер обращается к серверному auth-роутеру. Сервер хранит `state`, `nonce`, `code_verifier` и `refresh_token` в cookie с флагом `httpOnly`. Фронтенд хранит декодированную сессию в памяти и отправляет access token, когда сервер возвращает его в JSON.

## Установка

Из GitHub:

```bash
npm install github:SESC-IT-Team/Lyceum-Auth-Frontend-Lib
```

Для локальной разработки:

```bash
npm run pack:check
npm install ../auth-lib/auth-lib-0.1.0.tgz
```

Пакет ожидает `react` и `react-dom` в качестве peer dependencies. Установите их в приложении, если они ещё не установлены.

## Примеры

```tsx
import React from "react";
import { AlertCircleIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";

import {
  // Хуки и компоненты библиотеки авторизации.
  useAuth,
  AuthProvider,
  AuthCallback,
  LoginButton,
  LogoutButton,
  UserInfo,
  type AuthClientConfig,
} from "auth-lib";

// Адрес API, на котором работает auth-роутер.
const API_ORIGIN = "http://localhost:8000";

// Этот URL должен совпадать с LOGIN_REDIRECT_URI в настройках OAuth-клиента.
const LOGIN_REDIRECT_URI = "http://localhost:4000/auth/callback";

// Конфигурация передаётся в AuthProvider один раз при создании клиента.
const authConfig: AuthClientConfig = {
  baseUrl: API_ORIGIN,
  authPath: "/auth",
  // null означает: брать данные пользователя только из id_token.
  userInfoPath: null,
  // Запрашиваем стандартные OpenID Connect scope.
  scope: ["openid", "profile", "email", "offline_access"],
};

// Проверяем, вернулся ли браузер с успешным или ошибочным OAuth-ответом.
const isAuthCallbackUrl = () => {
  const query = new URLSearchParams(window.location.search);
  return (query.has("code") && query.has("state")) || query.has("error");
};

const Screen = () => {
  // status описывает состояние сессии, refresh повторно проверяет авторизацию.
  const { status, error, refresh } = useAuth();
  const [isCallback, setIsCallback] = React.useState(isAuthCallbackUrl);

  if (isCallback) {
    // Обмениваем code на токены и возвращаем пользователя на исходную страницу.
    return (
      <AuthCallback fallbackPath="/" onSuccess={() => setIsCallback(false)} />
    );
  }

  if (status === "loading") {
    // AuthProvider выполняет начальную тихую проверку сессии.
    return (
      <div className="flex items-center gap-2 text-muted-foreground text-sm">
        <Spinner />
        Проверяем сессию…
      </div>
    );
  }

  if (status === "error") {
    // Ошибку можно показать и повторить проверку сессии вручную.
    return (
      <div className="flex flex-col items-center gap-3 text-center">
        <AlertCircleIcon className="size-6 text-destructive" />
        <p className="text-sm">{error?.description ?? error?.message}</p>
        <Button onClick={() => void refresh()} variant="outline">
          Повторить
        </Button>
      </div>
    );
  }

  if (status === "authenticated") {
    // UserInfo показывает имя и email, LogoutButton завершает сессию.
    return (
      <div className="flex flex-col items-center gap-4">
        <UserInfo direction="vertical" />
        <LogoutButton variant="outline" />
      </div>
    );
  }

  return (
    // Для неавторизованного пользователя показываем кнопку входа.
    <div className="flex flex-col items-center gap-4">
      <p className="text-muted-foreground text-sm">Вы не авторизованы</p>
      <LoginButton size="lg" />
    </div>
  );
};

const App = () => {
  if (
    // В режиме разработки заранее выявляем несовпадение redirect URI и порта.
    import.meta.env.DEV &&
    !LOGIN_REDIRECT_URI.startsWith(window.location.origin)
  ) {
    console.error(
      `[auth] LOGIN_REDIRECT_URI is ${LOGIN_REDIRECT_URI}, but the app is served on ${window.location.origin}. ` +
        "Login will never complete. Align the env variable, the Authentik provider and the dev server port."
    );
  }

  return (
    // AuthProvider делает контекст доступным всем вложенным компонентам.
    <AuthProvider config={authConfig}>
      <div className="flex min-h-dvh items-center justify-center p-6">
        <Screen />
      </div>
    </AuthProvider>
  );
};

export default App;
```

`AuthCallback` нужно рендерить по точному URL, указанному на сервере в `LOGIN_REDIRECT_URI`. Компонент обменивает `code` и `state`, а затем удаляет OAuth-параметры запроса из истории браузера.

`UserInfo` отображает полное имя пользователя из claim `name` в `id_token`. При переданном свойстве `showEmail` email выводится под именем. Аватар компонент не отображает.

## Компоненты

### `AuthProvider`

Создаёт auth-клиент и React-контекст для дочерних компонентов. Выполняет тихое восстановление сессии при загрузке, хранит статус авторизации, текущую сессию и данные пользователя.

Основные свойства:

- `config` — настройки API, auth-роутера, scope и endpoint данных пользователя.
- `skipBootstrap` — отключает начальную проверку сессии.

`AuthProvider` должен оборачивать все компоненты, которые используют хуки библиотеки.

### `AuthCallback`

Обрабатывает OAuth callback URL. Обменивает `code` и `state` на токены, очищает OAuth-параметры из адреса и перенаправляет пользователя на сохранённый адрес.

Основные свойства:

- `fallbackPath` — путь по умолчанию, если адрес возврата не был сохранён.
- `onSuccess` — callback после успешного входа вместо автоматической навигации.
- `onError` — callback с объектом `AuthError` при ошибке.
- `pending` — собственный интерфейс загрузки.
- `renderError` — собственный интерфейс ошибки с функцией повторной попытки.

### `LoginButton`

Готовая кнопка входа. Запускает OAuth flow, показывает состояние загрузки и по умолчанию скрывается для уже авторизованного пользователя.

Основные свойства:

- `scope` — scope только для этого входа.
- `returnTo` — путь, на который нужно вернуться после входа.
- `hideWhenAuthenticated` — скрывать кнопку после входа.
- `hideIcon` — скрывать иконку входа.

Остальные свойства кнопки передаются базовому UI-компоненту `Button`.

### `LogoutButton`

Готовая кнопка выхода. Отзывает refresh token через `/auth/logout`, очищает локальную сессию и по умолчанию скрывается для неавторизованного пользователя.

Основные свойства:

- `federated` — дополнительно завершить SSO-сессию Authentik.
- `endSessionUrl` — endpoint завершения сессии Authentik.
- `postLogoutRedirectUri` — разрешённый URL возврата после федеративного выхода.
- `redirectTo` — локальный путь после обычного выхода.
- `hideWhenUnauthenticated` — скрывать кнопку без активной сессии.
- `hideIcon` — скрывать иконку выхода.

### `UserInfo`

Показывает полное имя текущего пользователя и, если указан `showEmail`, его email. Поддерживает горизонтальное и вертикальное расположение через `direction`.

Важно: текущая реализация `UserInfo` не отображает аватар и не использует свойство размера аватара.

### `UserFullName`

Отдельно показывает имя пользователя. Если имя отсутствует, компонент может использовать `preferred_username`, а затем email.

Основные свойства:

- `fallbackToUsername` — использовать имя пользователя вместо полного имени, по умолчанию `true`.
- `fallbackToEmail` — использовать email, если имя не найдено, по умолчанию `false`.

## Хуки

### `useAuth`

Возвращает полный auth-контекст: `client`, `status`, `error`, `session`, `claims`, `idToken`, `user`, `isUserLoading`, а также методы `login`, `logout`, `refresh`, `reloadUser` и `hasScope`.

### `useUser`

Возвращает данные текущего пользователя типа `AuthUser` или `null`. Пока данные загружаются либо пользователь вышел, возвращается `null`.

### `useIdToken`

Возвращает исходный `id_token` или `null`. Это значение предназначено для отображения и не должно использоваться как единственная проверка прав доступа.

### `useClaims`

Возвращает декодированные claims из `id_token` или `null`.

### `useIsAuthenticated`

Возвращает `true`, если текущий статус равен `authenticated`.

### `useAuthFetch`

Возвращает `fetch`, связанный с auth-сессией. Он автоматически передаёт cookie, добавляет Bearer-токен при наличии и повторяет запрос после ответа `401` с обновлённой сессией.

### `useHasScope`

Проверяет, был ли выдан указанный scope. Эта проверка подходит только для управления интерфейсом: сервер всё равно должен проверять права на каждом запросе.

## Клиент и типы

### `createAuthClient`

Создаёт framework-agnostic клиент без React. Клиент умеет запускать вход, обрабатывать callback, обновлять и отзывать сессию, загружать пользователя и выполнять авторизованные запросы.

### `AuthClientConfig`

Описывает конфигурацию клиента:

- `baseUrl` — origin API; пустая строка означает same-origin.
- `authPath` — путь auth-роутера, по умолчанию `/auth`.
- `scope` — запрашиваемые scope, по умолчанию `openid profile email offline_access`.
- `userInfoPath` — endpoint текущего пользователя, по умолчанию `/hello/`; `null` отключает запрос.
- `mapUser` — собственное преобразование ответа user-info в `AuthUser`.
- `refreshSkewSeconds` — за сколько секунд до истечения обновлять токен.
- `broadcastChannelName` — имя канала синхронизации между вкладками.
- `sessionMarkerCookie` — необязательная cookie-маркер наличия сессии.
- `returnToStorageKey` — ключ `sessionStorage` для адреса возврата.
- `fetchImpl` — альтернативная реализация `fetch`, например для тестов.

### `AuthSession`

Содержит `idToken`, возможный `accessToken`, claims обоих токенов, выданные scope и время истечения access token.

### `AuthUser`

Нормализованные данные пользователя: `id`, `fullName`, `initials`, `email`, `avatarUrl` и исходное поле `raw`. Поле `avatarUrl` сохраняется клиентом, но текущий `UserInfo` его не отображает.

### `AuthError`

Ошибка авторизации с полями `status`, `code` и `description`. Свойство `isUnauthenticated` помогает определить ответы `400`, `401` и `403`.

### `AUTH_SCOPES` и `DEFAULT_SCOPE`

`AUTH_SCOPES` содержит именованные стандартные и прикладные scope. `DEFAULT_SCOPE` включает `openid`, `profile`, `email` и `offline_access`.

### `decodeJwt`, `defaultMapUser`, `buildInitials` и `hasScope`

- `decodeJwt` декодирует payload JWT без проверки подписи; не используйте результат как самостоятельное доказательство безопасности.
- `defaultMapUser` преобразует ответ user-info и claims в `AuthUser`.
- `buildInitials` строит инициалы из полного имени.
- `hasScope` проверяет наличие scope в текущей сессии.

## Хуки

```tsx
import {
  useAuth,
  useAuthFetch,
  useClaims,
  useIdToken,
  useIsAuthenticated,
  useUser,
} from "auth-lib";

function Account() {
  const { status, refresh, logout } = useAuth();
  const user = useUser();
  const claims = useClaims();
  const idToken = useIdToken();
  const isAuthenticated = useIsAuthenticated();
  const authFetch = useAuthFetch();

  return null;
}
```

Используйте `authFetch` для API-запросов. Он передаёт cookie, добавляет `Authorization: Bearer ...`, когда доступен access token, и повторяет один запрос после ответа `401`, предварительно выполнив единичное обновление токена для параллельных запросов.

## Федеративный выход

Серверный endpoint `/auth/logout` выполняет локальный выход и отзывает refresh token. Чтобы также закрыть SSO-сессию Authentik, передайте endpoint завершения сессии Authentik:

```tsx
<LogoutButton
  federated
  endSessionUrl="https://authentik.example.com/application/o/test/end-session/"
  postLogoutRedirectUri={window.location.origin}
/>
```

`postLogoutRedirectUri` должен быть разрешён в настройках провайдера Authentik.

## Сборка и публикация

```bash
npm run build:package
npm pack
npm publish
```

Пакет содержит `dist`, этот README и `LICENSE`. Сгенерированная дистрибуция включает ESM, CommonJS, CSS и декларации TypeScript.

## React Compiler

В этом шаблоне включён React Compiler. Подробнее см. в [документации React](https://react.dev/learn/react-compiler).

Учтите, что это может повлиять на скорость разработки и сборки через Vite.

## Расширение конфигурации Oxlint

Для production-приложения рекомендуется включить правила линтера с проверкой типов. Для этого установите `oxlint-tsgolint` и измените `.oxlintrc.json`:

```json
{
  "$schema": "./node_modules/oxlint/configuration_schema.json",
  "plugins": ["react", "typescript", "oxc"],
  "options": {
    "typeAware": true
  },
  "rules": {
    "react/rules-of-hooks": "error",
    "react/only-export-components": ["warn", { "allowConstantExport": true }]
  }
}
```

Полный список правил и категорий доступен в [документации Oxlint](https://oxc.rs/docs/guide/usage/linter/rules).
